#include "stm8s.h"

int TIM4_INT_counter = 0;
_Bool TIM4_active = 0;
_Bool LED_ON = 1;
_Bool prev_state = 0;
_Bool curr_state = 0;

INTERRUPT_HANDLER(EXTI_PORTC_IRQHandler, 5)
{
    if(LED_ON == 0)
        LED_ON = 1;
    else
        LED_ON = 0;
}   

void main(void)
{
    EXTI_SetExtIntSensitivity(EXTI_PORT_GPIOC, EXTI_SENSITIVITY_FALL_ONLY);
    ITC_SetSoftwarePriority(ITC_IRQ_PORTC, ITC_PRIORITYLEVEL_0);

    enableInterrupts();

    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
    GPIO_Init(GPIOC, GPIO_PIN_5, GPIO_MODE_OUT_PP_LOW_SLOW);
    GPIO_Init(GPIOE, GPIO_PIN_4, GPIO_MODE_IN_FL_IT);

    //TIM4 setup
    TIM4_TimeBaseInit(TIM4_PRESCALER_128, 255);
    TIM4_Cmd(ENABLE);
    TIM4_active = 1;

    while (1)
    {
        if(TIM4_GetFlagStatus(TIM4_FLAG_UPDATE) == SET)
        {
            TIM4_ClearFlag(TIM4_FLAG_UPDATE);
            TIM4_INT_counter++;
        }
        if(TIM4_INT_counter == 500 && LED_ON == 1)
        {
            TIM4_INT_counter = 0;
            GPIO_WriteReverse(GPIOC, GPIO_PIN_5);
        }
    }
}
